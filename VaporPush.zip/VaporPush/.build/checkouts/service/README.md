<p align="center">
    <img src="https://user-images.githubusercontent.com/1342803/36576048-42ac84be-181c-11e8-9078-96e82e2cd3bd.png" width="320" alt="Service">
    <br>
    <br>
    <a href="https://docs.vapor.codes/3.0/service/getting-started/">
        <img src="http://img.shields.io/badge/read_the-docs-2196f3.svg" alt="Documentation">
    </a>
    <a href="http://vapor.team">
        <img src="http://vapor.team/badge.svg" alt="Slack Team">
    </a>
    <a href="LICENSE">
        <img src="http://img.shields.io/badge/license-MIT-brightgreen.svg" alt="MIT License">
    </a>
    <a href="https://circleci.com/gh/vapor/service">
        <img src="https://circleci.com/gh/vapor/service.svg?style=shield" alt="Continuous Integration">
    </a>
    <a href="https://swift.org">
        <img src="http://img.shields.io/badge/swift-4.1-brightgreen.svg" alt="Swift 4.1">
    </a>
</p>

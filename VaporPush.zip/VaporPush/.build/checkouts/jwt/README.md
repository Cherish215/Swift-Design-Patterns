<p align="center">
    <img src="https://user-images.githubusercontent.com/1342803/36768561-e10bba90-1c0d-11e8-85b5-f9d1e605cc8a.png" height="64" alt="JWT">
    <br>
    <br>
    <a href="https://docs.vapor.codes/3.0/jwt/getting-started/">
        <img src="http://img.shields.io/badge/read_the-docs-2196f3.svg" alt="Documentation">
    </a>
    <a href="https://discord.gg/vapor">
        <img src="https://img.shields.io/discord/431917998102675485.svg" alt="Team Chat">
    </a>
    <a href="LICENSE">
        <img src="http://img.shields.io/badge/license-MIT-brightgreen.svg" alt="MIT License">
    </a>
    <a href="https://circleci.com/gh/vapor/jwt">
        <img src="https://circleci.com/gh/vapor/jwt.svg?style=shield" alt="Continuous Integration">
    </a>
    <a href="https://swift.org">
        <img src="http://img.shields.io/badge/swift-4.1-brightgreen.svg" alt="Swift 4.1">
    </a>
</p>

<hr>

**Original author**

- Siemen Sikkema, [@siemensikkema](http://github.com/siemensikkema)  

import FluentBenchmark
import XCTest

final class FluentTests: XCTestCase {
    func testStub() throws { }
    static let allTests = [
        ("testStub", testStub),
    ]
}

extension Byte {
    /// ~
    @available (*, deprecated, renamed: "tilde")
    public static let tilda: Byte = 0x7E
}

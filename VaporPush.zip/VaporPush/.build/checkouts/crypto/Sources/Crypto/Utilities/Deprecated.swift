extension Digest {
    /// See `Digest.hash(_:)`
    @available(*, deprecated, renamed: "hash")
    public func digest(_ data: LosslessDataConvertible) throws -> Data {
        return try hash(data)
    }
}


extension OpaquePointer {
    func convert<T>() -> UnsafePointer<T> {
        return .init(self)
    }
    
    func convert<T>() -> UnsafeMutablePointer<T> {
        return .init(self)
    }
    
    func convert() -> OpaquePointer {
        return self
    }
}

extension UnsafePointer {
    func convert() -> OpaquePointer {
        return .init(self)
    }
}

extension UnsafeMutablePointer {
    func convert() -> OpaquePointer {
        return .init(self)
    }
}

<p align="center">
    <img src="https://user-images.githubusercontent.com/1342803/36575535-7278593c-1819-11e8-8104-69c10892a317.png" height="64" alt="Crypto">
    <br>
    <br>
    <a href="https://docs.vapor.codes/3.0/crypto/getting-started/">
        <img src="http://img.shields.io/badge/read_the-docs-2196f3.svg" alt="Documentation">
    </a>
    <a href="https://discord.gg/vapor">
        <img src="https://img.shields.io/discord/431917998102675485.svg" alt="Team Chat">
    </a>
    <a href="LICENSE">
        <img src="http://img.shields.io/badge/license-MIT-brightgreen.svg" alt="MIT License">
    </a>
    <a href="https://circleci.com/gh/vapor/crypto">
        <img src="https://circleci.com/gh/vapor/crypto.svg?style=shield" alt="Continuous Integration">
    </a>
    <a href="https://swift.org">
        <img src="http://img.shields.io/badge/swift-4.1-brightgreen.svg" alt="Swift 4.1">
    </a>
</p>

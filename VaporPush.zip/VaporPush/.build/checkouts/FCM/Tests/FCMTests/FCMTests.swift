import XCTest
@testable import FCM

final class FCMTests: XCTestCase {
    func testExample() {
        XCTAssertFalse(false)
    }


    static var allTests = [
        ("testExample", testExample),
    ]
}

import XCTest

import FCMTests

var tests = [XCTestCaseEntry]()
tests += FCMTests.allTests()
XCTMain(tests)
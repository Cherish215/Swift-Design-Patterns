/// SQL character collations.
public protocol SQLCollation: SQLSerializable { }

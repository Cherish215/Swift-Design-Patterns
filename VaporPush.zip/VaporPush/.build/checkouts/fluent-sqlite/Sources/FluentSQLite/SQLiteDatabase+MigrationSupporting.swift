extension SQLiteDatabase: MigrationSupporting { }

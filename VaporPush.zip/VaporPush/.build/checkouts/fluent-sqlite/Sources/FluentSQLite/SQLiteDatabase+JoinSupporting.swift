extension SQLiteDatabase: JoinSupporting {
    /// See `JoinSupporting`.
    public typealias QueryJoin = SQLiteJoin
    
    /// See `JoinSupporting`.
    public typealias QueryJoinMethod = SQLiteJoinMethod
}
